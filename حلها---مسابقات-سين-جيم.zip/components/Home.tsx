
import React from 'react';
import { View, User } from '../types';

interface HomeProps {
  setView: (view: View) => void;
  user: User | null;
  adminEmail: string;
}

export const Home: React.FC<HomeProps> = ({ setView, user, adminEmail }) => {
  const isAdmin = user?.role === 'admin';

  return (
    <div className="flex flex-col min-h-[80vh] bg-transparent font-['Tajawal']">
      <section className="py-32 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-12">
          <h1 className="text-8xl md:text-9xl font-black mb-8 leading-tight text-white drop-shadow-2xl">
            حلها
          </h1>

          <div className="flex flex-wrap justify-center gap-10 mt-20">
            <button 
              onClick={() => setView('GAME_SETUP')}
              className="group bg-blue-600 text-white px-20 py-8 rounded-full font-black text-4xl hover:bg-blue-700 hover:scale-105 transition-all shadow-2xl flex items-center gap-6 active:scale-95 border-b-8 border-blue-900"
            >
              <span>إنشاء لعبة</span>
              <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">🎮</div>
            </button>
            <button 
              onClick={() => setView('SHOP')}
              className="group bg-blue-400 text-white px-20 py-8 rounded-full font-black text-4xl hover:bg-blue-500 hover:scale-105 transition-all shadow-2xl flex items-center gap-6 active:scale-95 border-b-8 border-blue-600"
            >
              <span>المتجر</span>
              <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">🛒</div>
            </button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-6 pt-10">
            <button 
              onClick={() => setView('HISTORY')}
              className="bg-white/10 backdrop-blur-lg text-white border-2 border-white/20 px-12 py-4 rounded-full font-black text-xl hover:bg-white/20 transition-all shadow-xl active:scale-95 flex items-center gap-3"
            >
              <span>📔 السجل</span>
            </button>
            {isAdmin && (
              <button 
                onClick={() => setView('DASHBOARD')}
                className="bg-white/10 backdrop-blur-lg text-white border-2 border-white/20 px-12 py-4 rounded-full font-black text-xl hover:bg-white hover:text-blue-700 transition-all shadow-xl active:scale-95"
              >
                الإدارة
              </button>
            )}
          </div>
        </div>
      </section>

      <section className="py-32 px-4 max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          {[
            { icon: "🎨", title: "واجهات زرقاء", desc: "تصميم عصري مريح للعين يعتمد على درجات الأزرق الملكي.", color: "bg-white/10 border-white/10" },
            { icon: "🛡️", title: "وسائل مساعدة", desc: "نظام مساعدات احترافي لزيادة حماس التحدي.", color: "bg-white/10 border-white/10" },
            { icon: "📊", title: "تحكم فوري", desc: "لوحة تحكم سهلة لإدارة الأسئلة لحظة بلحظة.", color: "bg-white/10 border-white/10" }
          ].map((item, i) => (
            <div key={i} className={`text-center group space-y-8 p-16 rounded-[64px] border-4 ${item.color} hover:bg-white/5 transition-all duration-500 hover:shadow-3xl backdrop-blur-sm`}>
              <div className="w-28 h-28 bg-white/10 rounded-[40px] flex items-center justify-center mx-auto text-6xl mb-6 shadow-2xl border border-white/20 group-hover:rotate-6 transition-transform">{item.icon}</div>
              <h3 className="text-4xl font-black text-white">{item.title}</h3>
              <p className="text-white/50 leading-relaxed text-xl font-medium">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
