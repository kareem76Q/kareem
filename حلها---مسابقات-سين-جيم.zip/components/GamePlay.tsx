
import React, { useState, useEffect, useRef } from 'react';
import { GameState, Category, Question, Team } from '../types';

interface GamePlayProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState | null>>;
  onEndGame: () => void;
}

export const GamePlay: React.FC<GamePlayProps> = ({ gameState, setGameState, onEndGame }) => {
  const { selectedCategories, teams, answeredQuestionIds, activeQuestion, currentTurnIndex } = gameState;
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showAnswer, setShowAnswer] = useState(false);
  const [showTeamSelection, setShowTeamSelection] = useState(false);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (activeQuestion && !isPaused && !showAnswer && !showTeamSelection) {
      timerRef.current = window.setInterval(() => {
        setElapsedTime((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [activeQuestion, isPaused, showAnswer, showTeamSelection]);

  const toggleTurn = () => {
    setGameState(prev => prev ? { ...prev, currentTurnIndex: prev.currentTurnIndex === 0 ? 1 : 0 } : null);
  };

  const handleSelectQuestion = (categoryId: string, questionId: string) => {
    if (answeredQuestionIds.includes(questionId)) return;
    setShowAnswer(false);
    setShowTeamSelection(false);
    setElapsedTime(0);
    setGameState(prev => prev ? { ...prev, activeQuestion: { categoryId, questionId } } : null);
  };

  const handleAwardPoints = (teamIndex: number | null) => {
    setGameState(prev => {
      if (!prev || !prev.activeQuestion) return prev;
      const activeQ = prev.activeQuestion;
      const category = prev.selectedCategories.find(c => c.id === activeQ.categoryId);
      const question = category?.questions.find(q => q.id === activeQ.questionId);
      if (!question) return { ...prev, activeQuestion: null };

      const newTeams = [...prev.teams];
      if (teamIndex !== null) {
        newTeams[teamIndex] = { ...newTeams[teamIndex], score: newTeams[teamIndex].score + question.points };
      }

      return {
        ...prev,
        teams: newTeams as [Team, Team],
        answeredQuestionIds: [...prev.answeredQuestionIds, question.id],
        activeQuestion: null,
        currentTurnIndex: teamIndex !== null ? (teamIndex === 0 ? 1 : 0) : prev.currentTurnIndex
      };
    });
    setShowAnswer(false);
    setShowTeamSelection(false);
    setElapsedTime(0);
  };

  const activeQuestionData = activeQuestion 
    ? selectedCategories.find(c => c.id === activeQuestion.categoryId)?.questions.find(q => q.id === activeQuestion.questionId)
    : null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const currentImageUrl = showAnswer 
    ? activeQuestionData?.answerImageUrl
    : activeQuestionData?.questionImageUrl;

  return (
    <div className="h-screen w-full flex flex-col overflow-hidden text-white font-['Tajawal'] select-none bg-blue-900">
      
      {/* 1. Top Header Navigation */}
      <div className="h-14 bg-blue-700/80 backdrop-blur-md flex items-center justify-between px-6 border-b border-white/10 shadow-lg relative z-50">
        <div className="flex items-center gap-4">
          <button onClick={onEndGame} className="flex items-center gap-2 hover:text-blue-300 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            <span className="text-sm font-bold">الخروج</span>
          </button>
          <button 
            onClick={() => {
              setGameState(prev => prev ? {...prev, activeQuestion: null} : null);
              setShowTeamSelection(false);
            }}
            className="flex items-center gap-2 hover:text-blue-200 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>
            <span className="text-sm font-bold">الرجوع للوحة</span>
          </button>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTurn}
            className="bg-blue-600 hover:bg-blue-500 px-6 py-1 rounded-full border border-white/20 shadow-lg flex items-center gap-2 transition-all active:scale-95 group"
            title="اضغط لتبديل الدور"
          >
            <span className="text-xs text-white/50 font-bold">دور فريق:</span>
            <span className="text-sm font-black group-hover:text-blue-100">{teams[currentTurnIndex].name}</span>
            <svg className="w-4 h-4 text-white/30 group-hover:rotate-180 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        
        {/* 2. Main Game Area */}
        <main className="flex-1 p-4 md:p-6 flex flex-col items-center justify-center relative overflow-hidden">
          
          {activeQuestion ? (
            <div className="w-full h-full flex flex-col animate-in fade-in zoom-in-95 duration-500 max-w-6xl mx-auto">
              <div className="flex-1 bg-white rounded-[40px] border-[10px] border-blue-600/10 shadow-2xl relative overflow-hidden flex flex-col items-center p-6 md:p-10">
                
                {showTeamSelection ? (
                  <div className="w-full h-full flex flex-col items-center justify-center space-y-10 animate-in zoom-in-90 duration-300">
                    <h2 className="text-5xl md:text-6xl font-black text-blue-900 text-center mb-8">أي فريق جاوب صح؟</h2>
                    
                    <div className="flex flex-col sm:flex-row justify-center gap-6 w-full max-w-3xl">
                      <button 
                        onClick={() => handleAwardPoints(1)}
                        className="flex-1 bg-blue-700 hover:bg-blue-800 text-white py-6 md:py-8 rounded-[32px] text-3xl md:text-5xl font-black shadow-xl transition-all active:scale-95 border-b-8 border-blue-900"
                      >
                        {teams[1].name}
                      </button>
                      <button 
                        onClick={() => handleAwardPoints(0)}
                        className="flex-1 bg-blue-700 hover:bg-blue-800 text-white py-6 md:py-8 rounded-[32px] text-3xl md:text-5xl font-black shadow-xl transition-all active:scale-95 border-b-8 border-blue-900"
                      >
                        {teams[0].name}
                      </button>
                    </div>

                    <button 
                      onClick={() => handleAwardPoints(null)}
                      className="w-full max-w-sm bg-slate-400 hover:bg-slate-500 text-white py-4 md:py-6 rounded-[24px] text-2xl font-black shadow-lg transition-all active:scale-95 border-b-4 border-slate-600"
                    >
                      ولا أحد
                    </button>

                    <button 
                      onClick={() => setShowTeamSelection(false)}
                      className="text-blue-600 font-black text-xl hover:underline"
                    >
                      العودة للإجابة
                    </button>
                  </div>
                ) : (
                  <>
                    {!showAnswer && (
                      <div className="absolute top-0 left-1/2 -translate-x-1/2 flex items-center bg-blue-800 text-white rounded-b-2xl px-8 py-2 shadow-xl gap-4 z-10 scale-90 sm:scale-100">
                        <button onClick={() => setIsPaused(!isPaused)} className="hover:scale-110 transition-transform">
                          {isPaused ? <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg> : <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>}
                        </button>
                        <span className="text-xl font-black font-mono w-20 text-center">{formatTime(elapsedTime)}</span>
                        <button onClick={() => setElapsedTime(0)} className="hover:rotate-180 transition-all">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                        </button>
                      </div>
                    )}

                    <div className="absolute top-4 right-4 bg-blue-100 text-blue-900 px-5 py-1 rounded-full font-black text-sm border border-blue-200">
                      {activeQuestionData?.points} نقطة
                    </div>

                    <div className="flex-1 w-full flex flex-col items-center justify-center gap-6 overflow-hidden mt-8">
                       <h2 className="text-3xl md:text-5xl font-black text-blue-900 text-center leading-tight max-w-4xl px-4 animate-in slide-in-from-top-4 duration-300">
                          {showAnswer ? activeQuestionData?.answer : activeQuestionData?.text}
                       </h2>

                       {currentImageUrl && (
                          <div className="flex-1 w-full max-w-3xl bg-blue-50 rounded-[32px] overflow-hidden shadow-inner border border-blue-100 animate-in fade-in duration-500 relative group">
                             <img 
                                src={currentImageUrl} 
                                className="w-full h-full object-contain p-4 transition-transform duration-700" 
                                alt="Context"
                                onError={(e) => (e.currentTarget.style.display = 'none')}
                             />
                          </div>
                       )}
                    </div>

                    <div className="w-full flex flex-col sm:flex-row justify-between items-center gap-4 mt-8 pt-4 border-t border-blue-50">
                      <div className="flex items-center gap-4 w-full sm:w-auto">
                        {!showAnswer ? (
                          <button 
                            onClick={() => setShowAnswer(true)}
                            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 rounded-2xl font-black text-xl shadow-xl transition-all active:scale-95"
                          >
                            عرض الإجابة
                          </button>
                        ) : (
                          <button 
                            onClick={() => setShowAnswer(false)}
                            className="w-full sm:w-auto bg-slate-200 hover:bg-slate-300 text-blue-900 px-8 py-4 rounded-2xl font-black text-lg transition-all"
                          >
                            العودة للسؤال
                          </button>
                        )}
                      </div>
                      
                      {showAnswer && (
                        <button 
                          onClick={() => setShowTeamSelection(true)}
                          className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white px-12 py-4 rounded-2xl font-black text-xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2"
                        >
                          تحديد الفائز بالنقاط
                          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                        </button>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>
          ) : (
            <div className="w-full h-full animate-in fade-in duration-700 overflow-y-auto custom-scrollbar px-2">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4 min-h-full">
                {selectedCategories.map(cat => (
                  <div key={cat.id} className="flex flex-col gap-3">
                    <div className="bg-white text-blue-800 p-3 rounded-2xl shadow-lg flex flex-col items-center text-center gap-2 border-b-4 border-blue-200">
                      <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-blue-500 shadow-sm flex-shrink-0">
                         <img src={cat.imageUrl} className="w-full h-full object-cover" alt={cat.name} />
                      </div>
                      <span className="font-black text-xs md:text-sm truncate w-full">{cat.name}</span>
                    </div>
                    <div className="flex flex-col gap-2 flex-1">
                      {cat.questions.map(q => {
                        const isAnswered = answeredQuestionIds.includes(q.id);
                        return (
                          <button
                            key={q.id}
                            disabled={isAnswered}
                            onClick={() => handleSelectQuestion(cat.id, q.id)}
                            className={`flex-1 rounded-xl font-black text-2xl md:text-3xl transition-all shadow-md border-2 min-h-[60px] ${
                              isAnswered 
                              ? 'bg-blue-800/40 text-white/10 border-transparent cursor-not-allowed grayscale' 
                              : 'bg-white text-blue-700 border-blue-50 hover:bg-blue-50 hover:scale-105 active:scale-95'
                            }`}
                          >
                            {q.points}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>

        {/* 3. Right Sidebar */}
        <aside className="hidden lg:flex w-72 bg-blue-800/30 backdrop-blur-sm border-l border-white/10 p-6 flex-col gap-10 overflow-y-auto">
           {teams.map((team, idx) => (
             <div key={idx} className={`space-y-6 transition-all duration-300 ${currentTurnIndex === idx ? 'scale-105 opacity-100' : 'opacity-40 grayscale-[50%]'}`}>
                <div className="bg-blue-700 rounded-full py-2 px-6 shadow-xl border-b-4 border-blue-900 text-center font-black text-xl">
                   {team.name}
                </div>
                
                <div className="text-center">
                   <div className="text-6xl font-black text-white drop-shadow-md">{team.score}</div>
                   <div className="text-xs text-white/40 font-bold uppercase tracking-widest mt-2">مجموع النقاط</div>
                </div>

                <div className="space-y-3">
                   <div className="flex justify-center gap-3">
                      <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-xs font-bold opacity-30">وسيلة 1</div>
                      <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-xs font-bold opacity-30">وسيلة 2</div>
                   </div>
                </div>

                {idx === 0 && <div className="border-b border-white/5 my-4"></div>}
             </div>
           ))}
        </aside>
      </div>
    </div>
  );
};
