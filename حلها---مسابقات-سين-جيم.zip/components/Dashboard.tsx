
import React, { useState } from 'react';
import { Category, Question, User, GameHistoryItem } from '../types';

interface DashboardProps {
  categories: Category[];
  onUpdateCategories: (cats: Category[]) => void;
  allUsers: User[];
  onUpdateUser: (user: User) => void;
  allHistory: GameHistoryItem[];
}

export const Dashboard: React.FC<DashboardProps> = ({ categories, onUpdateCategories, allUsers, onUpdateUser, allHistory }) => {
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [activeTab, setActiveTab] = useState<'CATEGORIES' | 'USERS'>('CATEGORIES');
  const [selectedUserHistory, setSelectedUserHistory] = useState<User | null>(null);

  const addNewCategory = () => {
    const newCat: Category = {
      id: Date.now().toString(),
      name: 'فئة جديدة',
      imageUrl: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=400&h=300&auto=format&fit=crop',
      price: 3,
      isOwned: true,
      questions: Array.from({ length: 6 }, () => ({
        id: Math.random().toString(),
        text: '',
        answer: '',
        points: 200,
        questionImageUrl: '',
        answerImageUrl: ''
      }))
    };
    onUpdateCategories([...categories, newCat]);
    setEditingCategory(newCat);
  };

  const addQuestionToEditing = () => {
    if (!editingCategory) return;
    const newQuestion: Question = {
      id: Math.random().toString(),
      text: '',
      answer: '',
      points: 200,
      questionImageUrl: '',
      answerImageUrl: ''
    };
    setEditingCategory({
      ...editingCategory,
      questions: [...editingCategory.questions, newQuestion]
    });
  };

  const removeQuestionFromEditing = (qid: string) => {
    if (!editingCategory) return;
    setEditingCategory({
      ...editingCategory,
      questions: editingCategory.questions.filter(q => q.id !== qid)
    });
  };

  const updateQuestion = (idx: number, updates: Partial<Question>) => {
    if (!editingCategory) return;
    const newQuestions = [...editingCategory.questions];
    newQuestions[idx] = { ...newQuestions[idx], ...updates };
    setEditingCategory({ ...editingCategory, questions: newQuestions });
  };

  const deleteCategory = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه الفئة نهائياً؟')) {
      onUpdateCategories(categories.filter(c => c.id !== id));
    }
  };

  const handleSave = () => {
    if (editingCategory) {
      const updated = categories.map(c => c.id === editingCategory.id ? editingCategory : c);
      onUpdateCategories(updated);
      setEditingCategory(null);
    }
  };

  const getUserHistory = (email: string) => {
    return allHistory.filter(h => h.userEmail === email);
  };

  const handleAddBalance = (targetUser: User) => {
    const amountStr = prompt(`أدخل المبلغ المراد إضافته لرصيد ${targetUser.name}:`, "3");
    if (amountStr === null) return;
    
    const amount = parseFloat(amountStr);
    if (isNaN(amount)) {
      alert("الرجاء إدخال مبلغ صحيح");
      return;
    }
    
    // Ensure we use the latest user data and add numbers correctly
    const currentBalance = Number(targetUser.balance) || 0;
    const updated = { ...targetUser, balance: currentBalance + amount };
    
    onUpdateUser(updated);
    alert(`تمت إضافة ${amount}$ لرصيد ${targetUser.name} بنجاح.`);
  };

  const toggleUserRole = (targetUser: User) => {
    const newRole = targetUser.role === 'admin' ? 'user' : 'admin';
    const msg = newRole === 'admin' 
      ? `هل تريد ترقية ${targetUser.name} لمدير؟ سيتمكن من دخول لوحة التحكم هذه.`
      : `هل تريد إزالة صلاحيات المدير من ${targetUser.name}؟`;
    
    if (confirm(msg)) {
      onUpdateUser({ ...targetUser, role: newRole });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 bg-transparent space-y-10 font-['Tajawal'] text-right" dir="rtl">
      
      {/* Header & Tabs */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <h1 className="text-5xl font-black text-white">لوحة التحكم</h1>
          <div className="flex gap-4 mt-6">
            <button 
              onClick={() => setActiveTab('CATEGORIES')}
              className={`px-8 py-3 rounded-2xl font-black transition-all ${activeTab === 'CATEGORIES' ? 'bg-white text-blue-700 shadow-xl' : 'text-white/60 hover:text-white'}`}
            >
              إدارة الفئات
            </button>
            <button 
              onClick={() => setActiveTab('USERS')}
              className={`px-8 py-3 rounded-2xl font-black transition-all ${activeTab === 'USERS' ? 'bg-white text-blue-700 shadow-xl' : 'text-white/60 hover:text-white'}`}
            >
              إدارة المستخدمين ({allUsers.length})
            </button>
          </div>
        </div>
        {activeTab === 'CATEGORIES' && (
          <button 
            onClick={addNewCategory}
            className="bg-white text-blue-700 px-12 py-5 rounded-[24px] hover:bg-blue-50 transition-all shadow-2xl font-black text-xl active:scale-95 flex items-center gap-4"
          >
            <span className="text-3xl">+</span> إضافة فئة جديدة
          </button>
        )}
      </div>

      {activeTab === 'CATEGORIES' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10 animate-in fade-in slide-in-from-bottom-4">
          {categories.map(cat => (
            <div key={cat.id} className="bg-white/10 backdrop-blur-md overflow-hidden rounded-[40px] border-4 border-white/10 shadow-xl hover:shadow-2xl transition-all flex flex-col group">
              <div className="relative aspect-video overflow-hidden">
                <img src={cat.imageUrl} alt={cat.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all" />
                <div className="absolute inset-0 bg-blue-900/30"></div>
              </div>
              <div className="p-8 flex flex-col flex-grow">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-black text-white">{cat.name}</h3>
                  <span className="text-blue-200 font-black text-sm">{cat.price} $</span>
                </div>
                <p className="text-white/40 font-medium text-sm mb-8">تحتوي هذه الفئة على {cat.questions.length} سؤال</p>
                
                <div className="mt-auto flex gap-4">
                  <button 
                    onClick={() => setEditingCategory(cat)}
                    className="flex-1 bg-white text-blue-700 font-black py-4 rounded-2xl hover:bg-blue-50 transition-all"
                  >
                    تعديل
                  </button>
                  <button 
                    onClick={() => deleteCategory(cat.id)}
                    className="px-6 py-4 text-white hover:text-red-300 rounded-2xl transition-all font-black"
                  >
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="animate-in fade-in slide-in-from-bottom-4 space-y-6">
          <div className="bg-white/10 backdrop-blur-md rounded-[40px] border border-white/10 p-10 overflow-x-auto">
            <table className="w-full text-right border-collapse min-w-[800px]">
              <thead>
                <tr className="border-b border-white/10 font-black text-blue-200">
                  <th className="py-4 px-4 text-center">المستخدم</th>
                  <th className="py-4 px-4 text-center">الصلاحية</th>
                  <th className="py-4 px-4 text-center">كلمة المرور</th>
                  <th className="py-4 px-4 text-center">الرصيد الحالي</th>
                  <th className="py-4 px-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {allUsers.map((u, i) => (
                  <tr key={u.email || i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-4 text-center">
                      <div className="font-black text-white">{u.name}</div>
                      <div className="text-white/40 text-[10px]">{u.email}</div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <button 
                        onClick={() => toggleUserRole(u)}
                        className={`px-4 py-1.5 rounded-xl text-[11px] font-black uppercase transition-all shadow-md ${u.role === 'admin' ? 'bg-amber-500 text-white border border-amber-300' : 'bg-white/10 text-white/40 hover:bg-white/20'}`}
                        title="اضغط لتغيير الصلاحية"
                      >
                        {u.role === 'admin' ? 'إداري (Admin)' : 'مستخدم'}
                      </button>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="font-mono text-blue-300 text-sm bg-blue-900/40 px-3 py-1 rounded-lg">
                        {u.password || 'N/A'}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <div className="font-black text-blue-200 text-xl">{u.balance} $</div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex justify-center gap-2">
                        <button 
                          type="button"
                          onClick={() => handleAddBalance(u)}
                          className="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-xl text-xs font-black transition-all shadow-lg active:scale-95 flex items-center gap-2"
                        >
                          <span>+</span>
                          إضافة رصيد
                        </button>
                        <button 
                          onClick={() => setSelectedUserHistory(u)}
                          className="bg-white/10 hover:bg-white hover:text-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black transition-all"
                        >
                          السجل ({getUserHistory(u.email).length})
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Editing Modal for Categories */}
      {editingCategory && (
        <div className="fixed inset-0 bg-blue-900/80 z-[100] flex items-center justify-center p-4 backdrop-blur-md overflow-y-auto">
          <div className="bg-white w-full max-w-6xl my-auto rounded-[40px] shadow-2xl border-4 border-white overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="sticky top-0 bg-white border-b border-blue-50 px-8 py-6 flex justify-between items-center z-20">
              <h2 className="text-3xl font-black text-blue-700">تعديل فئة: {editingCategory.name}</h2>
              <button onClick={() => setEditingCategory(null)} className="bg-red-50 p-3 rounded-xl text-red-500 hover:bg-red-100 transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            
            <div className="p-8 max-h-[80vh] overflow-y-auto custom-scrollbar space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-blue-50 p-8 rounded-[32px]">
                <div className="space-y-2">
                  <label className="text-sm font-black text-blue-600 block">اسم الفئة</label>
                  <input value={editingCategory.name} onChange={e => setEditingCategory({...editingCategory, name: e.target.value})} className="w-full px-5 py-3 border-2 border-white rounded-2xl outline-none font-bold text-blue-900 bg-white" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-black text-blue-600 block">السعر ($)</label>
                  <input type="number" value={editingCategory.price} onChange={e => setEditingCategory({...editingCategory, price: Number(e.target.value)})} className="w-full px-5 py-3 border-2 border-white rounded-2xl outline-none font-bold text-blue-900 bg-white" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-black text-blue-600 block">رابط الصورة الرئيسية</label>
                  <input value={editingCategory.imageUrl} onChange={e => setEditingCategory({...editingCategory, imageUrl: e.target.value})} className="w-full px-5 py-3 border-2 border-white rounded-2xl outline-none font-bold text-blue-900 bg-white" />
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-black text-blue-900">إدارة الأسئلة ({editingCategory.questions.length})</h3>
                  <button onClick={addQuestionToEditing} className="bg-blue-600 text-white px-6 py-2 rounded-xl font-black hover:bg-blue-700 transition-all flex items-center gap-2">
                    <span>+</span> إضافة سؤال جديد
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-8">
                  {editingCategory.questions.map((q, idx) => (
                    <div key={q.id} className="bg-slate-50 p-8 rounded-[32px] border-2 border-blue-50 shadow-sm relative group">
                      <button onClick={() => removeQuestionFromEditing(q.id)} className="absolute top-4 left-4 text-red-400 hover:text-red-600 transition-colors font-black text-xs p-2 bg-white rounded-lg shadow-sm">
                        حذف
                      </button>
                      <div className="flex items-center gap-4 mb-6">
                         <span className="bg-blue-600 text-white px-5 py-1 rounded-full text-xs font-black">سؤال {idx + 1}</span>
                         <div className="flex items-center gap-2">
                            <label className="text-xs font-black text-blue-400">النقاط:</label>
                            <select value={q.points} onChange={e => updateQuestion(idx, { points: Number(e.target.value) })} className="bg-white border-2 border-white rounded-lg px-3 py-1 text-xs font-black text-blue-900 outline-none">
                              {[200, 400, 600, 800, 1000].map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                         </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <div className="space-y-2">
                             <label className="text-xs font-black text-blue-600 block">نص السؤال</label>
                             <textarea value={q.text} onChange={e => updateQuestion(idx, { text: e.target.value })} className="w-full px-5 py-3 border-2 border-white bg-white rounded-2xl outline-none font-bold text-blue-900 min-h-[100px]" placeholder="اكتب السؤال هنا..." />
                          </div>
                          <div className="space-y-2">
                             <label className="text-xs font-black text-blue-600 block">الإجابة</label>
                             <input value={q.answer} onChange={e => updateQuestion(idx, { answer: e.target.value })} className="w-full px-5 py-3 border-2 border-white bg-white rounded-2xl outline-none font-bold text-blue-900" placeholder="اكتب الإجابة هنا..." />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-3">
                            <label className="text-xs font-black text-blue-600 block">صورة السؤال (رابط)</label>
                            <input value={q.questionImageUrl || ''} onChange={e => updateQuestion(idx, { questionImageUrl: e.target.value })} className="w-full px-4 py-2 border-2 border-white bg-white rounded-xl outline-none text-xs font-bold text-blue-900" placeholder="أدخل رابط صورة..." />
                            <div className="aspect-video rounded-xl border-2 border-dashed border-blue-200 bg-blue-50/50 flex items-center justify-center overflow-hidden">
                              {q.questionImageUrl ? <img src={q.questionImageUrl} alt="Preview" className="w-full h-full object-cover" /> : <span className="text-[10px] text-blue-300 font-bold">لا توجد صورة</span>}
                            </div>
                          </div>
                          <div className="space-y-3">
                            <label className="text-xs font-black text-blue-600 block">صورة الإجابة (رابط)</label>
                            <input value={q.answerImageUrl || ''} onChange={e => updateQuestion(idx, { answerImageUrl: e.target.value })} className="w-full px-4 py-2 border-2 border-white bg-white rounded-xl outline-none text-xs font-bold text-blue-900" placeholder="أدخل رابط صورة..." />
                            <div className="aspect-video rounded-xl border-2 border-dashed border-blue-200 bg-blue-50/50 flex items-center justify-center overflow-hidden">
                              {q.answerImageUrl ? <img src={q.answerImageUrl} alt="Preview" className="w-full h-full object-cover" /> : <span className="text-[10px] text-blue-300 font-bold">لا توجد صورة</span>}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-10 border-t sticky bottom-0 bg-white flex gap-4 pb-2">
                <button onClick={handleSave} className="flex-1 bg-blue-600 text-white font-black py-5 rounded-2xl hover:bg-blue-700 transition-all text-xl shadow-lg">حفظ جميع التعديلات</button>
                <button onClick={() => setEditingCategory(null)} className="px-10 py-5 bg-slate-100 text-slate-500 font-black rounded-2xl hover:bg-slate-200 transition-all text-xl">إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedUserHistory && (
        <div className="fixed inset-0 bg-blue-900/60 z-[100] flex items-center justify-center p-6 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-4xl max-h-[80vh] overflow-y-auto rounded-[60px] shadow-2xl p-12 text-blue-900">
            <div className="flex justify-between items-center mb-10">
              <div>
                <h2 className="text-3xl font-black">سجل ألعاب المستخدم</h2>
                <p className="text-blue-500 font-bold">{selectedUserHistory.name} ({selectedUserHistory.email})</p>
              </div>
              <button onClick={() => setSelectedUserHistory(null)} className="bg-blue-50 p-4 rounded-2xl text-blue-400 hover:text-red-500 transition-colors font-black">إغلاق</button>
            </div>
            {getUserHistory(selectedUserHistory.email).length === 0 ? (
              <div className="text-center py-20 bg-blue-50 rounded-[40px] border-4 border-dashed border-blue-100 text-blue-300 font-black text-2xl">لا توجد ألعاب مسجلة</div>
            ) : (
              <div className="space-y-4">
                {getUserHistory(selectedUserHistory.email).map(item => (
                  <div key={item.id} className="bg-blue-50 p-6 rounded-[32px] border-2 border-blue-100 flex items-center justify-between gap-6">
                    <div className="flex flex-col">
                      <span className="text-xs text-blue-400 font-bold">{item.date}</span>
                      <div className="flex items-center gap-3 text-lg font-black mt-1">
                        <span>{item.teams[0].name} ({item.teams[0].score}) vs {item.teams[1].name} ({item.teams[1].score})</span>
                      </div>
                    </div>
                    <div className="bg-white px-6 py-2 rounded-2xl border border-blue-200"><span className="font-black text-blue-700">{item.winner}</span></div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
