
import React from 'react';
import { GameHistoryItem } from '../types';

interface HistoryProps {
  history: GameHistoryItem[];
}

export const History: React.FC<HistoryProps> = ({ history }) => {
  return (
    <div className="max-w-5xl mx-auto px-6 py-20 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-6xl font-black text-white">سجل الألعاب</h1>
        <p className="text-2xl text-white/50">استعرض نتائج المنافسات السابقة</p>
      </div>

      {history.length === 0 ? (
        <div className="bg-white/10 p-20 rounded-[48px] border-4 border-dashed border-white/10 text-center">
          <span className="text-8xl mb-8 block opacity-20">📔</span>
          <p className="text-white/40 text-2xl font-black">لا يوجد ألعاب مسجلة حتى الآن</p>
        </div>
      ) : (
        <div className="space-y-6">
          {history.map((item) => (
            <div key={item.id} className="bg-white/10 backdrop-blur-md p-8 rounded-[40px] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-8 hover:bg-white/20 transition-all group">
              <div className="flex flex-col gap-2">
                <span className="text-blue-200 font-black text-sm uppercase tracking-widest">{item.date}</span>
                <div className="flex items-center gap-4 text-3xl font-black">
                   <span className={item.winner === item.teams[0].name ? 'text-amber-400' : 'text-white'}>{item.teams[0].name} ({item.teams[0].score})</span>
                   <span className="text-white/20">ضد</span>
                   <span className={item.winner === item.teams[1].name ? 'text-amber-400' : 'text-white'}>{item.teams[1].name} ({item.teams[1].score})</span>
                </div>
              </div>
              
              <div className="bg-white/10 px-8 py-4 rounded-3xl border border-white/10 flex items-center gap-4 group-hover:border-amber-400/50">
                 <span className="text-white/40 text-sm font-bold">الفائز:</span>
                 <span className="text-2xl font-black text-amber-400">{item.winner}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
