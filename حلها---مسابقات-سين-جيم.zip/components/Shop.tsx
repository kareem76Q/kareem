
import React, { useState } from 'react';
import { User } from '../types';

interface ShopProps {
  user: User | null;
  onPurchaseBalance: (gamesAmount: number, cost: number) => void;
  gameCost: number;
}

export const Shop: React.FC<ShopProps> = ({ user, onPurchaseBalance, gameCost }) => {
  const [selectedPackage, setSelectedPackage] = useState<{ title: string; price: number; games: number } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');

  const packages = [
    { title: "لعبة واحدة", price: gameCost * 1, icon: "🎮", games: 1 },
    { title: "لعبتين", price: (gameCost * 2) - 1, icon: "🎮🎮", games: 2 }, // Discount for 2
    { title: "5 ألعاب", price: (gameCost * 5) - 5, icon: "🏆", games: 5 }, // Bigger discount
    { title: "10 ألعاب", price: (gameCost * 10) - 10, icon: "🔥", games: 10 }, // Massive discount
  ];

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) return;
    
    setIsProcessing(true);
    // Simulate payment delay
    setTimeout(() => {
      onPurchaseBalance(selectedPackage.games, selectedPackage.price);
      setIsProcessing(false);
      setSelectedPackage(null);
      setCardNumber('');
      setCardName('');
      alert('تمت عملية الدفع بنجاح! شكراً لتعاملك معنا.');
    }, 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-20 space-y-20 font-['Tajawal'] text-right" dir="rtl">
      
      {/* Package Selection Section */}
      <div className="bg-white/10 backdrop-blur-md rounded-[60px] p-12 border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-[100px]"></div>
        <div className="text-center space-y-4 mb-16 relative z-10">
           <h2 className="text-6xl font-black text-white">متجر الألعاب</h2>
           <p className="text-white/60 text-2xl font-medium">سعر اللعبة الواحدة هو {gameCost}$ فقط</p>
           {user && (
             <div className="inline-block mt-4 bg-white/10 backdrop-blur-md text-white px-10 py-4 rounded-[32px] font-black text-2xl border border-white/10 shadow-xl">
               رصيدك الحالي: <span className="text-blue-200">{user.balance} $</span>
             </div>
           )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
           {packages.map((pkg, i) => (
             <button 
                key={i} 
                onClick={() => setSelectedPackage(pkg)}
                className="group bg-white/10 hover:bg-white transition-all duration-500 p-10 rounded-[48px] border-4 border-white/5 hover:border-white shadow-xl flex flex-col items-center text-center gap-6"
              >
                <span className="text-5xl group-hover:scale-125 transition-transform duration-500">{pkg.icon}</span>
                <h3 className="text-4xl font-black text-white group-hover:text-blue-700">{pkg.title}</h3>
                <div className="bg-black/20 px-6 py-2 rounded-full text-white group-hover:bg-blue-100 group-hover:text-blue-700 font-black text-2xl transition-colors">
                   {pkg.price} $
                </div>
                <p className="text-white/40 group-hover:text-blue-700/60 text-sm font-bold uppercase tracking-widest">اختر الباقة</p>
             </button>
           ))}
        </div>
      </div>

      {/* Checkout Modal */}
      {selectedPackage && (
        <div className="fixed inset-0 bg-blue-900/60 z-[100] flex items-center justify-center p-6 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-xl rounded-[60px] shadow-2xl border-8 border-white p-12 text-blue-900">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-4xl font-black">إتمام الدفع</h2>
                <button onClick={() => setSelectedPackage(null)} className="text-slate-400 hover:text-red-500 font-black text-2xl">X</button>
              </div>

              <div className="bg-blue-50 p-6 rounded-3xl mb-8 flex justify-between items-center border-2 border-blue-100">
                 <div>
                    <p className="text-blue-400 font-bold text-sm">الباقة المختارة:</p>
                    <p className="text-2xl font-black">{selectedPackage.title}</p>
                 </div>
                 <div className="text-3xl font-black text-blue-700">{selectedPackage.price} $</div>
              </div>

              <form onSubmit={handleCheckout} className="space-y-6">
                <div>
                  <label className="block text-sm font-black text-blue-600 mb-2">اسم صاحب البطاقة</label>
                  <input 
                    required 
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="الاسم كما يظهر على البطاقة" 
                    className="w-full bg-blue-50/50 border-4 border-blue-50 focus:border-blue-400 rounded-2xl px-6 py-4 outline-none font-bold text-right"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-blue-600 mb-2">رقم البطاقة</label>
                  <input 
                    required 
                    maxLength={16}
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="0000 0000 0000 0000" 
                    className="w-full bg-blue-50/50 border-4 border-blue-50 focus:border-blue-400 rounded-2xl px-6 py-4 outline-none font-bold text-left tracking-widest"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-black text-blue-600 mb-2">تاريخ الانتهاء</label>
                    <input required placeholder="MM/YY" className="w-full bg-blue-50/50 border-4 border-blue-50 focus:border-blue-400 rounded-2xl px-6 py-4 outline-none font-bold text-center" />
                  </div>
                  <div>
                    <label className="block text-sm font-black text-blue-600 mb-2">رمز الأمان CVV</label>
                    <input required maxLength={3} placeholder="000" className="w-full bg-blue-50/50 border-4 border-blue-50 focus:border-blue-400 rounded-2xl px-6 py-4 outline-none font-bold text-center" />
                  </div>
                </div>

                <button 
                  disabled={isProcessing}
                  className={`w-full bg-blue-600 text-white font-black py-6 rounded-[32px] text-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-4 ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'}`}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
                      جاري الدفع...
                    </>
                  ) : (
                    `دفع ${selectedPackage.price} $`
                  )}
                </button>
              </form>
           </div>
        </div>
      )}

      <div className="text-center py-20 bg-white/5 rounded-[60px] border-2 border-dashed border-white/10">
        <p className="text-white/40 text-xl font-bold">بوابات دفع آمنة ومشفرة 🔒</p>
      </div>
    </div>
  );
};
