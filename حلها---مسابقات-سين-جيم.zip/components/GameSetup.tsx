
import React, { useState } from 'react';
import { Category, GameState } from '../types';

interface GameSetupProps {
  categories: Category[];
  onStartGame: (state: GameState) => void;
  userBalance: number;
  gameCost: number;
}

export const GameSetup: React.FC<GameSetupProps> = ({ categories, onStartGame, userBalance, gameCost }) => {
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [team1Name, setTeam1Name] = useState('فريق 1');
  const [team2Name, setTeam2Name] = useState('فريق 2');

  const toggleCategory = (id: string) => {
    setSelectedCategoryIds(prev => {
      if (prev.includes(id)) return prev.filter(cid => cid !== id);
      if (prev.length >= 6) return prev;
      return [...prev, id];
    });
  };

  const handleStart = () => {
    if (selectedCategoryIds.length < 6) return;
    if (userBalance < gameCost) return;
    
    const selectedCats = categories.filter(c => selectedCategoryIds.includes(c.id));
    onStartGame({
      selectedCategories: selectedCats,
      teams: [
        { name: team1Name, score: 0 },
        { name: team2Name, score: 0 }
      ],
      answeredQuestionIds: [],
      activeQuestion: null,
      currentTurnIndex: 0
    });
  };

  const filteredCategories = categories.filter(cat => 
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 space-y-12 bg-transparent font-['Tajawal']">
      
      <div className="text-center">
        <h1 className="text-6xl font-black text-white drop-shadow-lg">اختر الفئات</h1>
      </div>

      <div className="flex flex-col items-center gap-6">
        <div className="relative w-full max-w-xl flex items-center">
          <input 
            type="text" 
            placeholder="البحث باسم الفئة" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white text-slate-900 rounded-full py-4 pr-6 pl-20 text-right font-bold shadow-2xl outline-none"
          />
          <button className="absolute left-1 bg-blue-700 hover:bg-blue-800 text-white p-3 rounded-full transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </button>
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-sm rounded-[40px] p-10 border border-white/10 relative">
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-8 py-2 rounded-full font-black text-lg shadow-xl z-10">
          الفئات المتاحة ({selectedCategoryIds.length}/6)
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6 pt-6">
          {filteredCategories.map(cat => {
            const isSelected = selectedCategoryIds.includes(cat.id);
            const questionCount = cat.questions.length;
            const gamesEquivalent = Math.floor(questionCount / 6);

            return (
              <div 
                key={cat.id} 
                onClick={() => toggleCategory(cat.id)}
                className={`group cursor-pointer flex flex-col items-center gap-3 transition-all duration-300 relative ${
                  isSelected ? 'scale-95' : 'hover:scale-105'
                }`}
              >
                {/* Information Badge */}
                <div className="absolute -top-1 -right-1 z-20">
                  <div className="bg-blue-600 text-[10px] font-black text-white px-2 py-1 rounded-md shadow-lg border border-white/20 transform rotate-3">
                    {questionCount} أسئلة - {gamesEquivalent} لعبة
                  </div>
                </div>

                <div className={`w-full aspect-[4/5] rounded-3xl overflow-hidden border-4 transition-all duration-500 shadow-xl ${
                  isSelected 
                    ? 'border-blue-400 ring-4 ring-blue-400/30' 
                    : 'border-transparent group-hover:border-white/20'
                }`}>
                  <img src={cat.imageUrl} alt={cat.name} className={`w-full h-full object-cover transition-all ${isSelected ? 'brightness-110' : 'brightness-75'}`} />
                </div>

                <div className={`w-full py-2 px-4 rounded-xl text-center font-black transition-all ${
                  isSelected ? 'bg-blue-600 text-white shadow-lg' : 'bg-white/10 text-white group-hover:bg-white/20'
                }`}>
                  {cat.name}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex flex-col items-center gap-10 bg-white/5 p-12 rounded-[50px] border border-white/10 backdrop-blur-md">
        <div className="flex flex-wrap justify-center items-center gap-10 w-full">
           <div className="flex-1 min-w-[250px] space-y-4">
              <input value={team1Name} onChange={e => setTeam1Name(e.target.value)} className="w-full bg-white/10 border-2 border-white/20 rounded-2xl py-4 text-center font-black text-2xl text-white outline-none focus:border-blue-400" placeholder="اسم الفريق الأول" />
           </div>
           <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-blue-800 font-black text-3xl shadow-2xl rotate-12">VS</div>
           <div className="flex-1 min-w-[250px] space-y-4">
              <input value={team2Name} onChange={e => setTeam2Name(e.target.value)} className="w-full bg-white/10 border-2 border-white/20 rounded-2xl py-4 text-center font-black text-2xl text-white outline-none focus:border-blue-400" placeholder="اسم الفريق الثاني" />
           </div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <div className="text-white/60 font-bold">
            رصيدك: <span className="text-blue-200">{userBalance} $</span>
          </div>
          <button
            onClick={handleStart}
            disabled={selectedCategoryIds.length !== 6}
            className={`px-24 py-8 rounded-full font-black text-4xl transition-all shadow-2xl active:scale-95 border-b-8 ${
              selectedCategoryIds.length === 6 
              ? 'bg-blue-600 text-white hover:bg-blue-700 border-blue-900' 
              : 'bg-white/10 text-white/20 cursor-not-allowed border-transparent'
            }`}
          >
            بدء التحدي
          </button>
        </div>
      </div>
    </div>
  );
};
