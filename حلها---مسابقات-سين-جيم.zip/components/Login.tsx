
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (name: string, email: string, isSignUp: boolean, password?: string) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password && (!isSignUp || name)) {
      onLogin(name, email, isSignUp, password);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 bg-white p-12 rounded-[60px] shadow-2xl border-8 border-white/10">
      <div className="text-center mb-10">
        <div className="bg-blue-600 w-20 h-20 rounded-3xl mx-auto mb-8 flex items-center justify-center text-white text-4xl font-black shadow-xl">ح</div>
        <h2 className="text-4xl font-black text-blue-900 mb-2">{isSignUp ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}</h2>
        <p className="text-blue-400 font-medium">{isSignUp ? 'انضم إلى عائلة حلها' : 'مرحباً بك في عالم التحدي والمعرفة'}</p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {isSignUp && (
          <div>
            <label className="block text-sm font-black text-blue-600 mb-2 uppercase tracking-wider text-right">الاسم الكامل</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-6 py-4 rounded-[20px] border-4 border-blue-50 bg-blue-50/30 focus:bg-white focus:border-blue-400 outline-none transition-all text-lg font-bold text-blue-900 text-right"
              placeholder="أدخل اسمك"
            />
          </div>
        )}
        <div>
          <label className="block text-sm font-black text-blue-600 mb-2 uppercase tracking-wider text-right">البريد الإلكتروني</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-6 py-4 rounded-[20px] border-4 border-blue-50 bg-blue-50/30 focus:bg-white focus:border-blue-400 outline-none transition-all text-lg font-bold text-blue-900 text-right"
            placeholder="example@mail.com"
          />
        </div>
        <div>
          <label className="block text-sm font-black text-blue-600 mb-2 uppercase tracking-wider text-right">كلمة المرور</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-6 py-4 rounded-[20px] border-4 border-blue-50 bg-blue-50/30 focus:bg-white focus:border-blue-400 outline-none transition-all text-lg font-bold text-blue-900 text-right"
            placeholder="••••••••"
          />
        </div>
        
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 px-4 rounded-[24px] transition-all shadow-xl text-xl mt-4 active:scale-95"
        >
          {isSignUp ? 'إنشاء حساب' : 'دخول'}
        </button>
      </form>

      <div className="mt-8 pt-6 border-t border-blue-50 text-center">
        <button 
          onClick={() => setIsSignUp(!isSignUp)}
          className="text-blue-600 font-black hover:text-blue-800 transition-colors"
        >
          {isSignUp ? 'لديك حساب بالفعل؟ سجل دخول' : 'ليس لديك حساب؟ سجل الآن'}
        </button>
      </div>
    </div>
  );
};
