
import React from 'react';
import { User, View } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  currentView: View;
  setView: (view: View) => void;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, user, currentView, setView, onLogout }) => {
  if (currentView === 'GAME_PLAY') return <div className="immersive-bg">{children}</div>;

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen flex flex-col immersive-bg">
      <header className="bg-white/10 backdrop-blur-md border-b border-white/10 sticky top-0 z-50 h-16 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex items-center gap-8 h-full">
            <div className="cursor-pointer flex items-center gap-2" onClick={() => setView('HOME')}>
              <div className="bg-white w-10 h-10 rounded-xl flex items-center justify-center text-blue-600 font-black text-xl shadow-lg">ح</div>
              <span className="text-white font-black text-2xl tracking-tight hidden sm:block uppercase">حلها</span>
            </div>
            
            <nav className="flex items-center gap-6">
              <button onClick={() => setView('HOME')} className={`text-sm font-bold transition-colors ${currentView === 'HOME' ? 'text-blue-200 underline underline-offset-4' : 'text-white/70 hover:text-white'}`}>الرئيسية</button>
              {user?.isLoggedIn && (
                <>
                  <button onClick={() => setView('SHOP')} className={`text-sm font-bold transition-colors ${currentView === 'SHOP' ? 'text-blue-200 underline underline-offset-4' : 'text-white/70 hover:text-white'}`}>المتجر</button>
                  <button onClick={() => setView('HISTORY')} className={`text-sm font-bold transition-colors ${currentView === 'HISTORY' ? 'text-blue-200 underline underline-offset-4' : 'text-white/70 hover:text-white'}`}>السجل</button>
                  {isAdmin && (
                    <button onClick={() => setView('DASHBOARD')} className={`text-sm font-bold transition-colors ${currentView === 'DASHBOARD' ? 'text-blue-200 underline underline-offset-4' : 'text-white/70 hover:text-white'}`}>لوحة التحكم</button>
                  )}
                </>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {user?.isLoggedIn ? (
              <div className="flex items-center gap-3">
                <div className="text-xs text-right hidden sm:block">
                  <p className="font-bold text-white">{user.name}</p>
                  <div className="flex gap-2 justify-end items-center">
                    <span className="text-blue-200 font-black">{user.balance} $</span>
                    <span className="text-white/20">|</span>
                    <button onClick={onLogout} className="text-white hover:text-blue-200 font-bold">خروج</button>
                  </div>
                </div>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 shadow-inner ${isAdmin ? 'bg-amber-500 border-amber-300' : 'bg-blue-500 border-white/20'}`}>
                  {isAdmin ? (
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                  ) : (
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                    </svg>
                  )}
                </div>
              </div>
            ) : (
              <button onClick={() => setView('LOGIN')} className="bg-white text-blue-600 px-6 py-2 rounded-full text-sm font-bold hover:bg-blue-50 transition-all shadow-lg active:scale-95">دخول</button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="py-8 text-center bg-black/10 backdrop-blur-sm border-t border-white/5 mt-auto">
        <p className="text-white/40 text-sm font-medium">حلها - منصة التحدي التفاعلية &copy; {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
};
